module.exports.config = {
name: "spam",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "𝐀𝐒𝐈𝐅 𝐱𝟔𝟗",
	description: "",
	commandCategory: "Admin - Tools",
	usages: "spam",
	cooldowns: 5,
	dependencies: "",
};

module.exports.run = function ({ api, event, Users }) {
   const god = ["100000862816633", "100000862816633"];
     if (!god.includes(event.senderID)) return api.sendMessage(`⚠️You don't have permission to use this command!`, event.threadID, event.messageID);
	var { threadID, messageID } = event;
	var k = function (k) { api.sendMessage(k, threadID)};

	//*vonglap
	
for (i = 200; i < 2; i++) {
 k("ওই কেউ স্পেম করিছ না 😒");
}
}	