 module.exports.config = {
  name: "capcutmodlink",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Jonell Magallanes",
  description: "Links Download",
  commandCategory: "[Capcut Links Dl]",
  cooldowns: 5
};

module.exports.run = ({ event, api }) =>                               api.sendMessage('Capcut Mod Apk\n\n\nLastest Version (8.9.0)\n🔗Original Package\n•https://www.mediafire.com/file/983kn19g0z6kaaz/CCPRO_890_V7A_28JULY.apk/file\n\n🔗Clone Package\n•https://www.mediafire.com/file/fun7drxvu1i8bxo/CCPRO_890_CLONE_28JULY.apk/file\n\n\nCapcut Mods Old Ver. \n\n•https://www.mediafire.com/file/a4ogew5j0yvy2fu/CAPCUT_PRO_780_V7A.apk/file\n\n\nCredit: ASIF x69\n\nhttps://t.me/teameditmods', event.threadID, event.messageID);                                                                                     